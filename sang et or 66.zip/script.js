
document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle');
 const nav=document.querySelector('nav');
 if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});}
 const year=document.querySelectorAll('[data-year]');
 year.forEach(el=>el.textContent=new Date().getFullYear());
 const form=document.querySelector('[data-contact-form]');
 if(form){form.addEventListener('submit',e=>{e.preventDefault();const status=form.querySelector('[data-form-status]');if(status)status.textContent="Le formulaire est prêt visuellement, mais son envoi n’est pas encore connecté. Pour recevoir les messages, il faudra configurer une adresse e-mail ou un service de formulaire avant la mise en ligne.";});}
});
